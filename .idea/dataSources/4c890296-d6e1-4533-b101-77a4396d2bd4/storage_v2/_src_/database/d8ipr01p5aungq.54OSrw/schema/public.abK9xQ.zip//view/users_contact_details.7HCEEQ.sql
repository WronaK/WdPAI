create view users_contact_details(id_user, email, name, phone) as
SELECT users.id_user,
       users.email,
       users_details.name,
       users_details.phone
FROM (users
         LEFT JOIN users_details ON ((users.id_users_details = users_details.id_user_details)));

