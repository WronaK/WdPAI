create view ad_details
            (id_ad, property_type, area, number_of_rooms, price, description, city, street, number_of_house, postcode,
             description_of_target_group, created_at, image, "like", email, name, phone)
as
SELECT advertisments.id_ad,
       advertisments.property_type,
       advertisments.area,
       advertisments.number_of_rooms,
       advertisments.price,
       advertisments.description,
       advertisments.city,
       advertisments.street,
       advertisments.number_of_house,
       advertisments.postcode,
       advertisments.description_of_target_group,
       advertisments.created_at,
       advertisments.image,
       advertisments."like",
       users_contact_details.email,
       users_contact_details.name,
       users_contact_details.phone
FROM (advertisments
         LEFT JOIN users_contact_details ON ((advertisments.id_assigned_by = users_contact_details.id_user)));

