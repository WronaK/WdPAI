create view ad_save
            (id_ad, property_type, area, number_of_rooms, price, description, city, street, number_of_house, postcode,
             description_of_target_group, created_at, image, "like", id_users)
as
SELECT advertisments.id_ad,
       advertisments.property_type,
       advertisments.area,
       advertisments.number_of_rooms,
       advertisments.price,
       advertisments.description,
       advertisments.city,
       advertisments.street,
       advertisments.number_of_house,
       advertisments.postcode,
       advertisments.description_of_target_group,
       advertisments.created_at,
       advertisments.image,
       advertisments."like",
       users_advertisments.id_users
FROM (users_advertisments
         LEFT JOIN advertisments ON ((users_advertisments.id_advertisments = advertisments.id_ad)));

